DROP DATABASE IF EXISTS USERS;
CREATE DATABASE USERS;
USE USERS;

DROP TABLE IF EXISTS `Register`;
CREATE TABLE `Register` (
  `id` int(5) NOT NULL auto_increment,
  `Firstname` char(35) NOT NULL default '',
  `Lastname` char(35) NOT NULL default '',
  `Password` char(15) NOT NULL default '',
  `email` char(40) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4080 DEFAULT CHARSET=utf8mb4;

LOCK TABLES `Usernames` WRITE;

INSERT INTO `Usernames` VALUES (1,'Adrian','Taylor', 'test1', 'adriant98@gmail.com'),
(2,'Jamar', 'Hanson', "test2", 'jamarh99@gmail.com');
UNLOCK TABLES;

