<?php

session_start();


$host="localhost";
$user="root";
$password="";
$dbname="USERS";

$con = mysqli_connect($host, $user, $password, $dbname)
  or die ('Could not connect to the database server' . mysqli_connect_error());
  
if($con){
  //echo "Connection Successful";
}
?>
